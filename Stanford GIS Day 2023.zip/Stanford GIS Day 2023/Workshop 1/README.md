# Workshop 1

## Status
In Progress

## Intro to Planet & basic API (Search & Ordering)
Description: A brief overview of 8-band Planetscope imagery, with a hands-on introduction to using Planet APIs to search the data catalog and order imagery for local download.